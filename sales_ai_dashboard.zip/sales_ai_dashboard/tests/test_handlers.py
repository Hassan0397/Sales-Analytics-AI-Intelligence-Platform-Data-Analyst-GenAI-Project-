# tests/test_handlers.py
import pandas as pd # type: ignore
from sales_ai_dashboard.app import handle_local_query # type: ignore
from app import handle_local_query # type: ignore

def test_local_top_products_handler():
    # small sample sales
    df = pd.DataFrame({
        'product_id': ['P1','P1','P2'],
        'total_sale': [10,20,5]
    })
    # monkeypatch sales in app? instead we assume handler works similar
    # This is a stub; expand if you refactor handler into its own module
    assert True
