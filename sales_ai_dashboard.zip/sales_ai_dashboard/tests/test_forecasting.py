# tests/test_forecasting.py
import pandas as pd
from forecasting import forecast_product

def test_forecast_product_linear():
    ds = pd.date_range("2023-01-01", periods=18, freq='MS')
    y = list(range(100, 100+18))
    df = pd.DataFrame({'ds': ds, 'y': y})
    res = forecast_product(df, horizon_months=3, use_prophet=False)
    assert res.shape[0] == 3
