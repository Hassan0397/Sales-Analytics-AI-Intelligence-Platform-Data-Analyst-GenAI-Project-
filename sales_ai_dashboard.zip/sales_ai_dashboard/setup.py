from setuptools import setup, find_packages # type: ignore

setup(
    name="sales_ai_dashboard",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        # List your dependencies here
    ],
)