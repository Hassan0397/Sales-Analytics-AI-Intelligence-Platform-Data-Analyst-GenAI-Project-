# src/cleaning.py
import pandas as pd

def clean_sales(df):
    # example: ensure date column is datetime
    df['date'] = pd.to_datetime(df['date'])
    df = df.drop_duplicates()
    return df
