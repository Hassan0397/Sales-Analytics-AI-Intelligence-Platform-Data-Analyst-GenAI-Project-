# src/data_ingest.py
import pandas as pd

def load_sales(path='data/sales.csv'):
    return pd.read_csv(path)

if __name__ == "__main__":
    df = load_sales()
    print(df.head())
