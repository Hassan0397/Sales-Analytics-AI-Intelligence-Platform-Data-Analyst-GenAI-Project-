# src/backtesting.py
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error

def mape(y_true, y_pred):
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    mask = y_true != 0
    if mask.sum() == 0:
        return np.nan
    return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100

def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def backtest_time_series(monthly_df, model_forecast_fn, horizon_months=3, step_months=3):
    df = monthly_df.copy().sort_values('ds').reset_index(drop=True)
    results = []
    n = df.shape[0]
    min_history = 8
    if n < min_history + horizon_months:
        return {"error":"Not enough data for reliable backtest", "n_rows": n}

    for end_idx in range(min_history, n - horizon_months + 1, step_months):
        train = df.iloc[:end_idx]
        test = df.iloc[end_idx:end_idx+horizon_months]
        fc = model_forecast_fn(train, horizon_months=horizon_months)
        if 'yhat' in fc.columns:
            yhat = fc['yhat'].values[:len(test)]
        else:
            yhat = fc['yhat'].values[:len(test)]
        y_true = test['y'].values[:len(yhat)]
        results.append({
            "train_end": train['ds'].iloc[-1],
            "mape": mape(y_true, yhat),
            "rmse": rmse(y_true, yhat),
            "n_train": len(train)
        })
    return pd.DataFrame(results)
