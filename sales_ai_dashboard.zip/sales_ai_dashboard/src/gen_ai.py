# Gen_ai.py - Enhanced GenAI Module
import os
import openai
import pandas as pd
import streamlit as st
from typing import Optional, Dict, Any, Tuple
import hashlib
import json
import time
from datetime import datetime, timedelta

# Cache configuration
CACHE_DIR = ".genai_cache"
os.makedirs(CACHE_DIR, exist_ok=True)

def get_cache_key(prompt: str, model: str) -> str:
    """Generate a unique cache key for prompt and model"""
    content = f"{prompt}_{model}"
    return hashlib.md5(content.encode()).hexdigest()

def save_to_cache(key: str, data: str, ttl_minutes: int = 60):
    """Save response to cache with TTL"""
    cache_file = os.path.join(CACHE_DIR, f"{key}.json")
    cache_data = {
        'data': data,
        'timestamp': datetime.now().isoformat(),
        'ttl_minutes': ttl_minutes
    }
    with open(cache_file, 'w') as f:
        json.dump(cache_data, f)

def load_from_cache(key: str) -> Optional[str]:
    """Load response from cache if not expired"""
    cache_file = os.path.join(CACHE_DIR, f"{key}.json")
    
    if not os.path.exists(cache_file):
        return None
    
    try:
        with open(cache_file, 'r') as f:
            cache_data = json.load(f)
        
        # Check TTL
        cache_time = datetime.fromisoformat(cache_data['timestamp'])
        ttl = timedelta(minutes=cache_data['ttl_minutes'])
        
        if datetime.now() - cache_time > ttl:
            # Cache expired
            os.remove(cache_file)
            return None
        
        return cache_data['data']
    except Exception:
        # If cache is corrupted, remove it
        try:
            os.remove(cache_file)
        except:
            pass
        return None

def init_client():
    """Initialize OpenAI client with comprehensive error handling"""
    api_key = os.getenv('OPENAI_API_KEY')
    
    if not api_key:
        # Check if API key is in Streamlit secrets
        try:
            api_key = st.secrets.get("OPENAI_API_KEY")
        except:
            pass
    
    if not api_key:
        raise ValueError(
            'OPENAI_API_KEY environment variable not found. '
            'Set it before running or configure in Streamlit secrets.'
        )
    
    try:
        client = openai.OpenAI(api_key=api_key)
        return client
    except Exception as e:
        raise ValueError(f"Failed to initialize OpenAI client: {str(e)}")

def dataframe_summary(df, max_rows=200, include_sample=True):
    """
    Return a comprehensive data summary for AI analysis.
    
    Args:
        df: DataFrame to summarize
        max_rows: Maximum rows to include in sample
        include_sample: Whether to include data sample
    
    Returns:
        Tuple of (csv_text, stats_dict, data_profile)
    """
    if df.empty:
        return "", {"error": "Empty DataFrame"}, {}
    
    # Data sample for context
    csv_text = ""
    if include_sample:
        sample = df.head(max_rows).copy()
        # Optimize sample for token efficiency
        for c in sample.select_dtypes(include=['object']).columns:
            sample[c] = sample[c].astype(str).str.slice(0, 100)
        csv_text = sample.to_csv(index=False)
    
    # Enhanced statistics
    stats_dict = {
        'shape': df.shape,
        'columns': list(df.columns),
        'memory_usage_mb': df.memory_usage(deep=True).sum() / 1024 / 1024,
        'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()}
    }
    
    # Numeric columns summary
    numeric_cols = df.select_dtypes(include=['number']).columns
    if len(numeric_cols) > 0:
        numeric_stats = df[numeric_cols].describe().to_dict()
        stats_dict['numeric_stats'] = numeric_stats
    
    # Categorical columns summary
    categorical_cols = df.select_dtypes(include=['object', 'category']).columns
    categorical_stats = {}
    for col in categorical_cols[:10]:
        try:
            value_counts = df[col].value_counts().head(10).to_dict()
            categorical_stats[col] = {
                'unique_count': df[col].nunique(),
                'top_values': value_counts,
                'null_count': df[col].isnull().sum()
            }
        except:
            continue
    
    if categorical_stats:
        stats_dict['categorical_stats'] = categorical_stats
    
    # Data quality indicators
    stats_dict['quality_indicators'] = {
        'total_null_count': df.isnull().sum().sum(),
        'duplicate_rows': df.duplicated().sum(),
        'completeness_score': (1 - df.isnull().sum().sum() / (df.shape[0] * df.shape[1])) * 100
    }
    
    # Data profile for AI context
    data_profile = generate_data_profile(df)
    
    return csv_text, stats_dict, data_profile

def generate_data_profile(df) -> Dict[str, Any]:
    """Generate a comprehensive data profile for better AI understanding"""
    profile = {
        'overview': {
            'total_records': len(df),
            'total_columns': len(df.columns),
            'data_types_breakdown': dict(df.dtypes.value_counts()),
        },
        'temporal_analysis': {},
        'business_context': {}
    }
    
    # Detect temporal patterns
    date_cols = [col for col in df.columns if any(x in col.lower() for x in ['date', 'time', 'timestamp'])]
    if date_cols:
        for col in date_cols[:2]:
            try:
                df[col] = pd.to_datetime(df[col], errors='coerce')
                valid_dates = df[col].dropna()
                if not valid_dates.empty:
                    profile['temporal_analysis'][col] = {
                        'range': {
                            'start': valid_dates.min().strftime('%Y-%m-%d'),
                            'end': valid_dates.max().strftime('%Y-%m-%d'),
                            'days_span': (valid_dates.max() - valid_dates.min()).days
                        },
                        'coverage': len(valid_dates) / len(df) * 100
                    }
            except:
                continue
    
    # Detect business context
    value_cols = [col for col in df.columns if any(x in col.lower() for x in 
                  ['sale', 'revenue', 'price', 'amount', 'cost', 'profit', 'quantity'])]
    if value_cols:
        profile['business_context']['value_columns'] = value_cols
    
    product_cols = [col for col in df.columns if any(x in col.lower() for x in 
                   ['product', 'item', 'sku', 'category'])]
    if product_cols:
        profile['business_context']['product_columns'] = product_cols
    
    customer_cols = [col for col in df.columns if any(x in col.lower() for x in 
                    ['customer', 'client', 'user', 'region'])]
    if customer_cols:
        profile['business_context']['customer_columns'] = customer_cols
    
    return profile

def ask_openai(
    prompt: str, 
    model: str = 'gpt-4o-mini', 
    temperature: float = 0.1,
    max_tokens: int = 1024,
    use_cache: bool = True,
    cache_ttl: int = 60
) -> Optional[str]:
    """
    Safely call OpenAI API with comprehensive error handling and caching.
    """
    
    # Check cache first
    if use_cache:
        cache_key = get_cache_key(prompt, model)
        cached_response = load_from_cache(cache_key)
        if cached_response:
            return cached_response
    
    try:
        client = init_client()
        
        # Add retry logic for transient errors
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = client.chat.completions.create(
                    model=model,
                    messages=[{'role': 'user', 'content': prompt}],
                    temperature=temperature,
                    max_tokens=max_tokens,
                    timeout=30
                )
                
                result = response.choices[0].message.content
                
                # Cache successful response
                if use_cache and result:
                    save_to_cache(cache_key, result, cache_ttl)
                
                return result
                
            except openai.RateLimitError:
                if attempt < max_retries - 1:
                    wait_time = 2 ** attempt
                    time.sleep(wait_time)
                    continue
                else:
                    raise
                    
            except openai.APITimeoutError:
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                else:
                    raise
    
    except openai.RateLimitError:
        return "⚠️ **OpenAI API Rate Limit Exceeded** - Using enhanced demo insights."
    
    except openai.APIConnectionError:
        return "🔌 **OpenAI API Connection Error** - Using enhanced demo insights."
    
    except openai.AuthenticationError:
        return "🔑 **OpenAI Authentication Error** - Using demo mode."
    
    except openai.APIError as e:
        return f"⚠️ **OpenAI API Error**: {str(e)} - Using enhanced sample analysis."
    
    except Exception as e:
        return f"❌ **Unexpected Error**: {str(e)} - Using demo insights."

def build_prompt_with_data(
    question: str, 
    df_csv: str, 
    stats_dict: Dict, 
    data_profile: Dict,
    instructions: Optional[str] = None,
    context: Optional[str] = None
) -> str:
    """
    Build an optimized prompt with data context for better AI responses.
    """
    
    base_instructions = instructions or """You are an expert data analyst and business intelligence assistant. 

CRITICAL GUIDELINES:
1. Use the provided data to answer questions precisely
2. If exact calculations aren't possible with sample data, explain what's needed
3. Provide actionable business insights when relevant
4. Suggest next steps for analysis
5. Format responses with clear sections and bullet points for readability
6. Include specific numbers and metrics when available
7. Highlight potential data quality issues
8. Recommend visualizations that would be helpful

RESPONSE STRUCTURE:
- Start with direct answer to the question
- Provide supporting analysis and calculations
- Include business implications
- Suggest next steps or additional analysis"""

    # Build enhanced context
    enhanced_context = f"""
DATA PROFILE:
- Records: {data_profile.get('overview', {}).get('total_records', 'N/A')}
- Columns: {data_profile.get('overview', {}).get('total_columns', 'N/A')}
- Data Types: {data_profile.get('overview', {}).get('data_types_breakdown', {})}

BUSINESS CONTEXT DETECTED:
{json.dumps(data_profile.get('business_context', {}), indent=2)}

DATA QUALITY:
{json.dumps(stats_dict.get('quality_indicators', {}), indent=2)}
"""

    if context:
        enhanced_context += f"\nADDITIONAL CONTEXT:\n{context}"

    prompt = f"""{base_instructions}

{enhanced_context}

DATA SAMPLE (First 200 rows):
{df_csv}

DATA STATISTICS:
{json.dumps(stats_dict, indent=2)}

USER QUESTION:
{question}

Please provide a comprehensive, actionable response that helps the user make data-driven decisions."""

    return prompt

def get_enhanced_demo_insights(prompt: str) -> str:
    """
    Provide sophisticated demo insights when OpenAI is unavailable.
    """
    
    prompt_lower = prompt.lower()
    
    if any(word in prompt_lower for word in ['revenue', 'sales', 'income']):
        return """**💰 Revenue Analysis (Enhanced Demo Insights)**

**Key Metrics:**
- Total Revenue: $2.8M (12.5% growth YoY)
- Average Order Value: $147.50
- Monthly Recurring Revenue: $234K

**Top Performing Categories:**
1. Electronics: $1.2M (+18% growth)
2. Audio Equipment: $650K (+28% growth) 
3. Wearables: $450K (+15% growth)

**Recommendations:**
1. Expand high-margin electronics category
2. Launch targeted promotional campaigns
3. Optimize inventory for seasonal demand

*Note: Connect to OpenAI API for precise analysis of your actual data.*"""

    elif any(word in prompt_lower for word in ['inventory', 'stock', 'supply']):
        return """**📦 Inventory Intelligence (Enhanced Demo Insights)**

**Stock Analysis:**
- Current Inventory Value: $1.8M
- Stock Turnover Ratio: 6.2
- Days of Inventory: 58 days

**Optimization Opportunities:**
- **Overstock Alert**: 22 items >90 days inventory
- **Restock Needed**: 8 items below safety stock

**Action Plan:**
1. Implement just-in-time ordering
2. Run promotions on slow-moving items
3. Increase safety stock for high-demand items

*Note: Actual inventory optimization requires your specific data analysis.*"""

    elif any(word in prompt_lower for word in ['product', 'item', 'sku']):
        return """**🏷️ Product Performance (Enhanced Demo Insights)**

**Portfolio Overview:**
- Total Products: 245 SKUs
- Active Products: 198 (81% of portfolio)

**Performance Tiers:**
🎯 **Stars (Top 10%)**
- Wireless Headphones: $450K revenue, 42% margin
- Smart Watches: $380K revenue, 38% margin

📈 **Growth (Next 20%)**  
- Bluetooth Speakers: +18% monthly growth
- Laptop Stands: +12% monthly growth

*Connect OpenAI API for your specific product analytics.*"""

    else:
        return """**📊 Business Intelligence Overview (Enhanced Demo Insights)**

**Overall Performance:**
- Revenue Growth: +15.2% MoM
- Customer Satisfaction: 4.3/5.0
- Operational Efficiency: 82%

**Strategic Recommendations:**
1. **Growth Opportunities**
   - Expand into adjacent product categories
   - Develop subscription service model

2. **Operational Excellence**
   - Automate inventory replenishment
   - Enhance customer segmentation

*To unlock full potential, connect your actual data with OpenAI API for personalized insights.*"""

def clear_genai_cache():
    """Clear all cached GenAI responses"""
    try:
        for file in os.listdir(CACHE_DIR):
            file_path = os.path.join(CACHE_DIR, file)
            if os.path.isfile(file_path):
                os.remove(file_path)
        return True
    except Exception:
        return False

def get_cache_stats() -> Dict[str, Any]:
    """Get statistics about cached responses"""
    try:
        files = [f for f in os.listdir(CACHE_DIR) if f.endswith('.json')]
        total_size = sum(os.path.getsize(os.path.join(CACHE_DIR, f)) for f in files)
        
        return {
            'total_cached_responses': len(files),
            'total_cache_size_mb': total_size / 1024 / 1024,
            'cache_directory': CACHE_DIR
        }
    except Exception:
        return {'total_cached_responses': 0, 'total_cache_size_mb': 0}