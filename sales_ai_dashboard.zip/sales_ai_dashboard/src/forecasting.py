# src/forecasting.py
import os
import pandas as pd
import numpy as np
from hashlib import sha256
import json

try:
    from prophet import Prophet
    HAS_PROPHET = True
except Exception:
    HAS_PROPHET = False

CACHE_DIR = os.getenv("FORECAST_CACHE_DIR", ".cache_forecasts")
os.makedirs(CACHE_DIR, exist_ok=True)

def _cache_path(key: str):
    h = sha256(key.encode("utf-8")).hexdigest()
    return os.path.join(CACHE_DIR, f"forecast_{h}.json")

def aggregate_monthly(df: pd.DataFrame, product_id=None):
    df2 = df.copy()
    if product_id:
        df2 = df2[df2["product_id"] == product_id]
    df2 = df2.dropna(subset=["date_parsed", "total_sale"])
    df2["month_start"] = pd.to_datetime(df2["date_parsed"]).dt.to_period("M").dt.to_timestamp()
    monthly = df2.groupby("month_start")["total_sale"].sum().reset_index().rename(columns={"month_start":"ds","total_sale":"y"})
    monthly = monthly.sort_values("ds").reset_index(drop=True)
    return monthly

def forecast_product(monthly_df: pd.DataFrame, horizon_months:int=3, use_prophet:bool=HAS_PROPHET):
    if monthly_df.shape[0] < 6:
        last = pd.to_datetime(monthly_df['ds'].max()) if not monthly_df.empty else pd.Timestamp.today()
        future = []
        for i in range(1, horizon_months+1):
            future.append({"ds": (last + pd.DateOffset(months=i)).to_period("M").to_timestamp(), "yhat": np.nan})
        return pd.DataFrame(future)

    key = json.dumps({
        "start": str(monthly_df['ds'].min()) if len(monthly_df)>0 else "",
        "end": str(monthly_df['ds'].max()),
        "rows": int(monthly_df.shape[0]),
        "horizon": horizon_months,
        "prophet": bool(use_prophet)
    })
    cache_file = _cache_path(key)
    if os.path.exists(cache_file):
        try:
            return pd.read_json(cache_file)
        except Exception:
            pass

    if use_prophet:
        try:
            m = Prophet(yearly_seasonality=True, weekly_seasonality=False, daily_seasonality=False)
            m.fit(monthly_df[['ds','y']])
            future = m.make_future_dataframe(periods=horizon_months, freq='M')
            forecast = m.predict(future)
            out = forecast[['ds','yhat','yhat_lower','yhat_upper']]
            out.to_json(cache_file, orient='records', date_format='iso')
            return out
        except Exception:
            use_prophet = False

    df = monthly_df.copy().reset_index(drop=True)
    df['t'] = np.arange(len(df))
    df['month'] = df['ds'].dt.month
    month_dummies = pd.get_dummies(df['month'], prefix='m', drop_first=True)
    X = pd.concat([df[['t']], month_dummies], axis=1)
    y = df['y']
    from sklearn.linear_model import LinearRegression
    model = LinearRegression()
    model.fit(X, y)
    last_t = df['t'].iloc[-1]
    future_ts = []
    future_months = []
    for i in range(1, horizon_months+1):
        next_month = (df['ds'].iloc[-1] + pd.DateOffset(months=i)).to_period('M').to_timestamp()
        future_ts.append(last_t + i)
        future_months.append(next_month.month)
    future_df = pd.DataFrame({'t': future_ts, 'month': future_months})
    future_month_dummies = pd.get_dummies(future_df['month'], prefix='m', drop_first=True)
    for col in X.columns[1:]:
        if col not in future_month_dummies.columns:
            future_month_dummies[col] = 0
    future_X = pd.concat([future_df[['t']].reset_index(drop=True), future_month_dummies[X.columns[1:]]], axis=1)
    preds = model.predict(future_X)
    out = pd.DataFrame({'ds': [(df['ds'].iloc[-1] + pd.DateOffset(months=i)).to_period('M').to_timestamp() for i in range(1,horizon_months+1)], 'yhat': preds})
    out.to_json(cache_file, orient='records', date_format='iso')
    return out

def forecast_top_products(df: pd.DataFrame, top_n:int=5, horizon_months:int=3, by='total_sale'):
    if by != 'total_sale':
        by = 'total_sale'
    prod_rank = df.groupby('product_id')[by].sum().sort_values(ascending=False).head(top_n).index.tolist()
    results = {}
    for p in prod_rank:
        monthly = aggregate_monthly(df, product_id=p)
        f = forecast_product(monthly, horizon_months=horizon_months)
        results[p] = {"monthly": monthly, "forecast": f}
    return results
