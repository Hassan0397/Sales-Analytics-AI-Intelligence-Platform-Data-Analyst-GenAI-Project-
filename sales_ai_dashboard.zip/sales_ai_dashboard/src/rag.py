# rag.py
import os
import numpy as np
import pandas as pd
from openai import OpenAI
import pickle
import json
from typing import List, Dict, Any, Optional
import hashlib

try:
    import faiss
    HAS_FAISS = True
except ImportError:
    HAS_FAISS = False

EMBED_CACHE = os.getenv("EMBED_CACHE_DIR", ".cache_embeddings")
os.makedirs(EMBED_CACHE, exist_ok=True)

class ProductRAG:
    def __init__(self, openai_api_key: str = None):
        self.api_key = openai_api_key or os.getenv('OPENAI_API_KEY')
        self.client = None
        if self.api_key:
            try:
                self.client = OpenAI(api_key=self.api_key)
            except Exception:
                pass
        self.index = None
        self.documents = []
        self.metadata = []
        self.is_initialized = False
        
    def embed_texts_openai(self, texts: List[str]) -> np.ndarray:
        """Embed texts using OpenAI with fallback to demo embeddings"""
        # Check cache first
        cache_key = hashlib.md5(str(texts).encode()).hexdigest()
        cache_file = os.path.join(EMBED_CACHE, f"{cache_key}.npy")
        
        if os.path.exists(cache_file):
            return np.load(cache_file)
        
        # Try OpenAI API
        if self.client:
            try:
                response = self.client.embeddings.create(
                    model="text-embedding-3-small",
                    input=texts
                )
                embeddings = [item.embedding for item in response.data]
                embeddings_array = np.array(embeddings).astype('float32')
                
                # Cache successful embeddings
                np.save(cache_file, embeddings_array)
                return embeddings_array
                
            except Exception as e:
                print(f"OpenAI embedding error, using demo embeddings: {e}")
        
        # Fallback: Generate deterministic demo embeddings
        return self._generate_demo_embeddings(texts)
    
    def _generate_demo_embeddings(self, texts: List[str]) -> np.ndarray:
        """Generate deterministic demo embeddings when OpenAI is unavailable"""
        embeddings = []
        for text in texts:
            # Create deterministic embedding based on text content
            hash_val = int(hashlib.md5(text.encode()).hexdigest()[:8], 16)
            np.random.seed(hash_val % (2**32))
            embedding = np.random.normal(0, 0.1, 1536).astype('float32')
            embeddings.append(embedding)
        return np.array(embeddings)
    
    def build_faiss_index(self, vectors: np.ndarray) -> Any:
        """Build FAISS index from vectors"""
        if not HAS_FAISS:
            raise RuntimeError("faiss not installed. Run: pip install faiss-cpu")
        
        dim = vectors.shape[1]
        self.index = faiss.IndexFlatIP(dim)
        self.index.add(vectors)
        return self.index
    
    def initialize_with_sample_data(self):
        """Initialize with sample product data"""
        sample_products = self._generate_sample_products()
        documents = []
        metadata = []
        
        for product in sample_products:
            doc_text = f"""
            Product: {product['name']} ({product['id']})
            Category: {product['category']}
            Description: {product['description']}
            Features: {', '.join(product['features'])}
            Price: {product['price']}
            Stock: {product['stock_status']}
            Margin: {product['margin']}
            Tags: {', '.join(product['tags'])}
            """
            documents.append(doc_text.strip())
            metadata.append(product)
        
        self.documents = documents
        self.metadata = metadata
        
        # Create embeddings and build index
        embeddings = self.embed_texts_openai(documents)
        self.build_faiss_index(embeddings)
        self.is_initialized = True
        
        print(f"✅ RAG system initialized with {len(documents)} products")
    
    def _generate_sample_products(self) -> List[Dict]:
        """Generate realistic sample product data"""
        return [
            {
                'id': 'P021',
                'name': 'Wireless Bluetooth Headphones',
                'category': 'Audio',
                'description': 'Premium noise-cancelling wireless headphones with 30-hour battery life and exceptional sound quality.',
                'features': ['Noise Cancellation', '30h Battery', 'Bluetooth 5.0', 'Voice Assistant'],
                'price': '$299.99',
                'stock_status': 'Low',
                'margin': 'High',
                'tags': ['audio', 'wireless', 'premium', 'electronics']
            },
            {
                'id': 'P015',
                'name': 'Gaming Mouse Pro',
                'category': 'Gaming',
                'description': 'High-precision gaming mouse with customizable RGB lighting and programmable buttons for competitive gaming.',
                'features': ['16000 DPI', 'RGB Lighting', 'Programmable Buttons', 'Ergonomic Design'],
                'price': '$79.99',
                'stock_status': 'Adequate',
                'margin': 'Medium',
                'tags': ['gaming', 'mouse', 'electronics', 'accessories']
            },
            {
                'id': 'P008',
                'name': 'Portable Bluetooth Speaker',
                'category': 'Audio',
                'description': 'Waterproof portable speaker with 360-degree sound, party lights, and 20-hour battery life.',
                'features': ['Waterproof', '360 Sound', 'Party Lights', '20h Battery'],
                'price': '$129.99',
                'stock_status': 'Needs Restock',
                'margin': 'High',
                'tags': ['audio', 'portable', 'waterproof', 'electronics']
            },
            {
                'id': 'P042',
                'name': 'Smart Fitness Watch',
                'category': 'Wearables',
                'description': 'Advanced fitness tracker with heart rate monitoring, GPS, sleep analysis, and smartphone connectivity.',
                'features': ['Heart Rate Monitor', 'GPS', 'Sleep Tracking', 'Smart Notifications'],
                'price': '$249.99',
                'stock_status': 'Good',
                'margin': 'High',
                'tags': ['wearables', 'fitness', 'smartwatch', 'health']
            },
            {
                'id': 'P033',
                'name': 'Mechanical Keyboard',
                'category': 'Computing',
                'description': 'Tactile mechanical keyboard with RGB backlighting, programmable macros, and durable construction.',
                'features': ['Mechanical Switches', 'RGB Lighting', 'Programmable', 'N-Key Rollover'],
                'price': '$149.99',
                'stock_status': 'Low',
                'margin': 'Medium',
                'tags': ['keyboard', 'mechanical', 'gaming', 'computing']
            },
            {
                'id': 'P056',
                'name': 'Laptop Stand Aluminum',
                'category': 'Accessories',
                'description': 'Adjustable aluminum stand for laptops that improves ergonomics and provides better cooling.',
                'features': ['Adjustable Height', 'Aluminum', 'Portable', 'Universal Fit'],
                'price': '$49.99',
                'stock_status': 'Good',
                'margin': 'Low',
                'tags': ['accessories', 'laptop', 'ergonomic', 'computing']
            },
            {
                'id': 'P067',
                'name': 'Wireless Charging Pad',
                'category': 'Accessories',
                'description': 'Fast wireless charger compatible with all Qi-enabled devices with safety features and LED indicators.',
                'features': ['Fast Charging', 'Qi-Compatible', 'LED Indicator', 'Overheat Protection'],
                'price': '$39.99',
                'stock_status': 'Adequate',
                'margin': 'Medium',
                'tags': ['accessories', 'charging', 'wireless', 'electronics']
            },
            {
                'id': 'P078',
                'name': '4K Webcam Pro',
                'category': 'Computing',
                'description': 'Ultra HD webcam with autofocus, noise-canceling microphone, and advanced low-light performance.',
                'features': ['4K Resolution', 'Autofocus', 'Noise Canceling', 'Low-light Correction'],
                'price': '$199.99',
                'stock_status': 'Good',
                'margin': 'High',
                'tags': ['webcam', 'video', 'computing', 'accessories']
            }
        ]
    
    def search(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        """Search for similar products with error handling"""
        if not self.is_initialized:
            self.initialize_with_sample_data()
        
        if self.index is None or len(self.documents) == 0:
            return []
        
        # Embed the query
        query_embedding = self.embed_texts_openai([query])
        
        # Search in FAISS index
        try:
            scores, indices = self.index.search(query_embedding, min(k, len(self.documents)))
        except Exception as e:
            print(f"FAISS search error: {e}")
            return self._get_fallback_results(query, k)
        
        # Format results
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < len(self.documents):
                results.append({
                    'document': self.documents[idx],
                    'metadata': self.metadata[idx],
                    'score': float(score),
                    'rank': len(results) + 1
                })
        
        return results if results else self._get_fallback_results(query, k)
    
    def _get_fallback_results(self, query: str, k: int) -> List[Dict]:
        """Provide fallback results when search fails"""
        sample_results = []
        products = self._generate_sample_products()
        
        # Simple keyword matching for fallback
        query_lower = query.lower()
        for product in products[:k]:
            score = 0.7  # Base score
            
            # Boost score based on keyword matches
            if any(word in query_lower for word in product['name'].lower().split()):
                score += 0.2
            if any(word in query_lower for word in product['category'].lower().split()):
                score += 0.1
            if any(word in query_lower for word in product['tags']):
                score += 0.1
            
            doc_text = f"""
            Product: {product['name']} ({product['id']})
            Category: {product['category']}
            Description: {product['description']}
            Features: {', '.join(product['features'])}
            Price: {product['price']}
            Stock: {product['stock_status']}
            Margin: {product['margin']}
            Tags: {', '.join(product['tags'])}
            """
            
            sample_results.append({
                'document': doc_text.strip(),
                'metadata': product,
                'score': min(0.95, score),  # Cap at 0.95
                'rank': len(sample_results) + 1
            })
        
        return sample_results
    
    def save_index(self, filepath: str):
        """Save the FAISS index and documents"""
        if self.index is None:
            raise ValueError("No index to save")
        
        faiss.write_index(self.index, f"{filepath}.index")
        
        with open(f"{filepath}_data.pkl", 'wb') as f:
            pickle.dump({
                'documents': self.documents,
                'metadata': self.metadata
            }, f)
    
    def load_index(self, filepath: str):
        """Load FAISS index and documents"""
        self.index = faiss.read_index(f"{filepath}.index")
        
        with open(f"{filepath}_data.pkl", 'rb') as f:
            data = pickle.load(f)
            self.documents = data['documents']
            self.metadata = data['metadata']
        
        self.is_initialized = True

# Enhanced standalone functions
def embed_texts_openai(texts: List[str], api_key: str = None) -> np.ndarray:
    """Standalone embedding function with error handling"""
    rag = ProductRAG(api_key)
    return rag.embed_texts_openai(texts)

def build_faiss_index(vectors: np.ndarray) -> Any:
    """Standalone FAISS index builder"""
    if not HAS_FAISS:
        raise RuntimeError("faiss not installed. Run: pip install faiss-cpu")
    
    dim = vectors.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(vectors.astype('float32'))
    return index

def demo_search(query: str, k: int = 5) -> List[Dict]:
    """Demo search function with enhanced fallback"""
    try:
        rag = ProductRAG()
        return rag.search(query, k)
    except Exception as e:
        print(f"Search error, using enhanced fallback: {e}")
        return _get_enhanced_fallback_results(query, k)

def _get_enhanced_fallback_results(query: str, k: int) -> List[Dict]:
    """Enhanced fallback results with better matching"""
    rag = ProductRAG()
    return rag._get_fallback_results(query, k)

# Global instance with error handling
_global_rag = None

def get_rag_system() -> ProductRAG:
    """Get or create global RAG system instance with error handling"""
    global _global_rag
    if _global_rag is None:
        _global_rag = ProductRAG()
        try:
            _global_rag.initialize_with_sample_data()
        except Exception as e:
            print(f"RAG initialization warning: {e}")
            # System will still work with fallback methods
    return _global_rag